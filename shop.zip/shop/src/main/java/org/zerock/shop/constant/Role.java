package org.zerock.shop.constant;

public enum Role {

    USER, ADMIN
}
