package org.zerock.shop.constant;

public enum ItemSellStatus {

    SELL, SOLD_OUT
}
