package org.zerock.shop.constant;

public enum OrderStatus {

    ORDER, CANCEL
}
